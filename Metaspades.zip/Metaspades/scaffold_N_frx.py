#!/usr/bin/python

from __future__ import print_function, division
from Bio import SeqIO, SeqUtils
import numpy as np
import matplotlib.pyplot as plt
import getopt
import sys

# GetOpts
try:
	opts, args = getopt.getopt(sys.argv[1:], 'i:o:v', ['input=', 'output=' 'verbose', ])
except getopt.GetOptError as err:
	print(err)
	sys.exit(2)
	
file_out = None
verbose = False
file_in = None

for opt, arg in opts:
	if opt in ('-i', '--input'):
		file_in = arg
	elif opt in ('-o', '--output'):
		file_out = arg
	elif opt in ('-v', '--verbose'):
		verbose = True

# Count number of scaffolds and distribution of scaffold sizes
recs = SeqIO.parse(open(file_in), 'fasta')
sizes = []
size_N = []
for rec in recs:
	size = len(rec.seq)
	sizes.append(size)
	count_N = 0
	for nuc in rec.seq:
		if nuc not in ['A', 'a', 'T', 't', 'C', 'c', 'G', 'g']:		# Handles degenerate base calls that arent Ns
			count_N += 1
	size_N.append((size, count_N / size))

if verbose == True:
	print('NUM SCAFFOLDS: ' + str(len(sizes)))
	print('SCAFFOLD MEDIAN: ' + str(np.median(sizes)))
	print('SCAFFOLD MEAN SIZE: ' + str(np.mean(sizes)))
	print('MAX SIZE: ' + str(max(sizes)))
	print('MIN SIZE: ' + str(min(sizes)))
	print('10th PERC: ' + str(np.percentile(sizes, 10)))
	print('90th PERC: ' + str(np.percentile(sizes, 90)))

# Write the same stats out to a txt file
stats = open("scaffold_stats.txt", "w")
stats.write('NUM SCAFFOLDS:\t' + str(len(sizes)))
stats.write('\nSCAFFOLD MEDIAN:\t' + str(np.median(sizes)))
stats.write('\nSCAFFOLD MEAN SIZE:\t' + str(np.mean(sizes)))
stats.write('\nMAX SIZE:\t' + str(max(sizes)))
stats.write('\nMIN SIZE:\t' + str(min(sizes)))
stats.write('\n10th PERC:\t' + str(np.percentile(sizes, 10)))
stats.write('\n90th PERC:\t' + str(np.percentile(sizes, 90)))
stats.close()

# Plot the fraction of the scaffolds (frx of Ns) as a function of scaffold size
small_split = 4800
large_split = 540000
fig, axs = plt.subplots(1, 3, figsize=(16, 9), squeeze=False)
xs, ys = zip(*[(x, 100 * y) for x, y in size_N if x <= small_split])
axs[0, 0].plot(xs, ys, '.')
axs[0, 0].set_ylim(-0.1, 3.5)
xs, ys = zip(*[(x, 100 * y) for x, y in size_N if x > small_split and x <= large_split])
axs[0, 1].plot(xs, ys, '.')
axs[0, 1].set_xlim(small_split, large_split)
xs, ys = zip(*[(x, 100 * y) for x, y in size_N if x > large_split])
axs[0, 2].plot(xs, ys, '.')
axs[0, 0].set_ylabel('Fraction of Ns (%)', fontsize=12)
axs[0, 1].set_xlabel('Contig size', fontsize=12)
fig.suptitle('Fraction of Ns per contig size', fontsize=26)
fig.savefig(file_out)
